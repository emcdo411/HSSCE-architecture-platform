"""
test_graph.py
HSSCE MVP — Basic pipeline tests.

These tests validate the structural integrity of the pipeline without
making live API calls. They use mock responses to verify that each
agent correctly parses its expected output format and that the
LangGraph state transitions work correctly.

To run:
  pytest tests/ -v
"""

import json
import pytest
from unittest.mock import MagicMock, patch

from app.models import (
    AICNOutput,
    ConflictRecord,
    ExecutiveBrief,
    HSSSEState,
    RawSource,
    ScenarioPathway,
    SignalRecord,
    SynthesisOutput,
    WeightedSignal,
    EscalationRisk,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def sample_raw_source() -> RawSource:
    return RawSource(
        title="Test Policy Document",
        url="https://example.com/test",
        source_type="policy_document",
        region="US",
        content="This is a test source about Cuba sanctions policy.",
        publication_date="2024-01-01",
    )


@pytest.fixture
def sample_signal_record() -> SignalRecord:
    return SignalRecord(
        id="test01",
        source_title="Test Policy Document",
        source_url="https://example.com/test",
        source_type="policy_document",
        signal_type="factual_claim",
        region="US",
        timestamp="2024-01-01",
        summary="A policy document discussing Cuba sanctions.",
        claims=["Sanctions have been in place for 60 years", "Migration has increased"],
        incentive_bias_flag=False,
        domain_relevance=4.0,
        time_sensitivity="MODERATE",
    )


@pytest.fixture
def sample_weighted_signal() -> WeightedSignal:
    return WeightedSignal(
        signal_id="test01",
        source_title="Test Policy Document",
        domain_proximity=4.0,
        track_record=3.5,
        incentive_bias_correction=0.9,
        timeliness_decay=0.95,
        raw_score=3.75,
        adjusted_weight=3.20,
        category="MODERATE",
        rationale="Policy document with reasonable domain proximity and no strong institutional bias.",
    )


@pytest.fixture
def sample_aicn_output(sample_weighted_signal) -> AICNOutput:
    return AICNOutput(
        weighted_signals=[sample_weighted_signal],
        conflicts=[],
        confidence_ceiling="MODERATE",
        convergence_summary="Signals broadly converge on economic pressure as primary driver.",
        residual_uncertainty=["Cuban government internal decision calculus is opaque"],
    )


@pytest.fixture
def sample_synthesis_output() -> SynthesisOutput:
    return SynthesisOutput(
        primary_assessment="Cuba faces a structural economic crisis that creates conditions for both escalation and cautious engagement.",
        scenario_pathways=[
            ScenarioPathway(
                name="Phased Normalization",
                description="Graduated US-Cuba engagement tied to humanitarian benchmarks.",
                likelihood="MODERATE",
                enabling_conditions=["US executive action on SSOT", "Cuban government acceptance of benchmarks"],
                blocking_conditions=["Congressional opposition", "Chinese veto via credit dependency"],
                timeline_estimate="18-36 months",
            )
        ],
        escalation_risks=[
            EscalationRisk(
                risk_label="Migration Surge",
                description="Continued economic deterioration drives migration spike.",
                severity="HIGH",
                trigger_conditions=["Further energy grid collapse"],
                mitigating_factors=["Regional cooperation framework"],
            )
        ],
        adversary_next_move="China will deepen credit dependency to prevent normalization that reduces Cuban strategic utility.",
        residual_uncertainty=["Cuban government internal decision calculus is opaque"],
        confidence_ceiling="MODERATE",
        reversal_conditions=["If Cuban government signals acceptance of political benchmarks"],
    )


# ---------------------------------------------------------------------------
# Model validation tests
# ---------------------------------------------------------------------------

class TestModelValidation:
    def test_raw_source_validates(self, sample_raw_source):
        assert sample_raw_source.title == "Test Policy Document"
        assert sample_raw_source.source_type == "policy_document"

    def test_signal_record_validates(self, sample_signal_record):
        assert sample_signal_record.domain_relevance == 4.0
        assert sample_signal_record.incentive_bias_flag is False
        assert sample_signal_record.time_sensitivity == "MODERATE"

    def test_weighted_signal_validates(self, sample_weighted_signal):
        assert sample_weighted_signal.category == "MODERATE"
        assert sample_weighted_signal.adjusted_weight == pytest.approx(3.20)

    def test_aicn_output_validates(self, sample_aicn_output):
        assert sample_aicn_output.confidence_ceiling == "MODERATE"
        assert len(sample_aicn_output.weighted_signals) == 1
        assert len(sample_aicn_output.conflicts) == 0

    def test_synthesis_output_validates(self, sample_synthesis_output):
        assert sample_synthesis_output.confidence_ceiling == "MODERATE"
        assert len(sample_synthesis_output.scenario_pathways) == 1
        assert "China" in sample_synthesis_output.adversary_next_move

    def test_hssse_state_initializes(self, sample_raw_source):
        state = HSSSEState(query="Test query", raw_sources=[sample_raw_source])
        assert state.query == "Test query"
        assert len(state.raw_sources) == 1
        assert len(state.errors) == 0
        assert state.run_id is not None


# ---------------------------------------------------------------------------
# AICN scoring formula tests
# ---------------------------------------------------------------------------

class TestAICNFormula:
    def test_raw_score_calculation(self):
        domain_proximity = 4.0
        track_record = 3.0
        expected_raw = (domain_proximity + track_record) / 2
        assert expected_raw == 3.5

    def test_adjusted_weight_calculation(self):
        raw_score = 3.5
        incentive_bias_correction = 0.8
        timeliness_decay = 0.9
        adjusted = raw_score * incentive_bias_correction * timeliness_decay
        assert adjusted == pytest.approx(2.52)

    def test_category_high(self):
        """Adjusted weight >= 4.0 should be HIGH"""
        adjusted = 4.5
        category = "HIGH" if adjusted >= 4.0 else "MODERATE"
        assert category == "HIGH"

    def test_category_degraded(self):
        """Adjusted weight < 1.0 should be DEGRADED"""
        adjusted = 0.8
        category = "DEGRADED" if adjusted < 1.0 else "LOW"
        assert category == "DEGRADED"


# ---------------------------------------------------------------------------
# State pipeline flow tests (no API calls)
# ---------------------------------------------------------------------------

class TestPipelineState:
    def test_state_carries_errors(self):
        state = HSSSEState(query="Test", raw_sources=[])
        state.errors.append("TestError: something failed")
        assert len(state.errors) == 1

    def test_state_serializes(self, sample_raw_source):
        state = HSSSEState(query="Test query", raw_sources=[sample_raw_source])
        dumped = state.model_dump()
        assert dumped["query"] == "Test query"
        assert isinstance(dumped["raw_sources"], list)

    def test_state_round_trips(self, sample_raw_source, sample_signal_record, sample_aicn_output):
        state = HSSSEState(
            query="Test query",
            raw_sources=[sample_raw_source],
            signal_records=[sample_signal_record],
            aicn_output=sample_aicn_output,
        )
        dumped = state.model_dump()
        restored = HSSSEState(**dumped)
        assert restored.aicn_output.confidence_ceiling == "MODERATE"
        assert len(restored.signal_records) == 1


# ---------------------------------------------------------------------------
# Storage tests
# ---------------------------------------------------------------------------

class TestStorage:
    def test_save_and_retrieve(self, tmp_path, sample_raw_source, monkeypatch):
        """Test that save_run and get_run work against a temp file."""
        import app.storage as storage_module
        runs_file = tmp_path / "runs.json"
        monkeypatch.setattr(storage_module, "RUNS_PATH", str(runs_file))

        state = HSSSEState(query="Storage test", raw_sources=[sample_raw_source])
        storage_module.save_run(state)

        retrieved = storage_module.get_run(state.run_id)
        assert retrieved is not None
        assert retrieved["query"] == "Storage test"

    def test_list_runs_empty(self, tmp_path, monkeypatch):
        import app.storage as storage_module
        runs_file = tmp_path / "runs.json"
        monkeypatch.setattr(storage_module, "RUNS_PATH", str(runs_file))

        runs = storage_module.list_runs()
        assert runs == []
