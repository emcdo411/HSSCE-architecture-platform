"""
models.py
HSSCE MVP — Pydantic data models for all pipeline stages.

These models enforce schema integrity across all four agents.
No agent may produce output that does not conform to its model.
"""

from __future__ import annotations
from typing import Any, Literal, Optional
from pydantic import BaseModel, Field
import uuid


# ---------------------------------------------------------------------------
# Input
# ---------------------------------------------------------------------------

class RawSource(BaseModel):
    """A source document provided by the caller before Signal Agent processing."""
    title: str
    url: Optional[str] = None
    source_type: str = Field(
        description="e.g. state_media, think_tank, journalism, policy_document, market_data"
    )
    region: str = Field(description="e.g. US, Cuba, Latin_America, China, Russia")
    content: str = Field(description="Full text or summary of source content")
    publication_date: Optional[str] = None


class AnalysisRequest(BaseModel):
    query: str
    sources: Optional[list[RawSource]] = None


# ---------------------------------------------------------------------------
# Stage 1 — Signal Agent output
# ---------------------------------------------------------------------------

class SignalRecord(BaseModel):
    """Normalized intelligence signal record produced by the Signal Agent."""
    id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    source_title: str
    source_url: Optional[str] = None
    source_type: str
    signal_type: str = Field(
        description="e.g. factual_claim, threat_assessment, economic_indicator, doctrine_statement"
    )
    region: str
    timestamp: Optional[str] = None
    summary: str
    claims: list[str] = Field(description="Discrete factual or analytical claims extracted from source")
    incentive_bias_flag: bool = Field(
        description="True if source has a clear institutional or political interest in a particular outcome"
    )
    domain_relevance: float = Field(ge=1.0, le=5.0, description="Relevance to the query domain")
    time_sensitivity: Literal["HIGH", "MODERATE", "LOW"]


# ---------------------------------------------------------------------------
# Stage 2 — AICN Calibration Agent output
# ---------------------------------------------------------------------------

class WeightedSignal(BaseModel):
    """AICN-calibrated signal with scoring rationale."""
    signal_id: str
    source_title: str
    domain_proximity: float = Field(ge=1.0, le=5.0)
    track_record: float = Field(ge=1.0, le=5.0)
    incentive_bias_correction: float = Field(ge=0.5, le=1.0)
    timeliness_decay: float = Field(ge=0.5, le=1.0)
    raw_score: float
    adjusted_weight: float
    category: Literal["HIGH", "MODERATE", "LOW", "DEGRADED"]
    rationale: str


class ConflictRecord(BaseModel):
    """Detected conflict between two or more signals."""
    conflict_type: Literal["FACTUAL", "INTERPRETIVE", "STRUCTURAL"]
    severity: Literal["CRITICAL", "SIGNIFICANT", "MINOR"]
    signals_involved: list[str] = Field(description="Signal IDs involved in conflict")
    description: str
    resolution_status: Literal["RESOLVED", "UNRESOLVED", "REFERRED_TO_RED_TEAM"]


class AICNOutput(BaseModel):
    weighted_signals: list[WeightedSignal]
    conflicts: list[ConflictRecord]
    confidence_ceiling: Literal["HIGH", "MODERATE", "LOW", "FRAGMENTED"]
    convergence_summary: str
    residual_uncertainty: list[str] = Field(
        description="Explicit statements of what remains unknown or unresolvable"
    )


# ---------------------------------------------------------------------------
# Stage 3 — Strategic Synthesis Agent output
# ---------------------------------------------------------------------------

class ScenarioPathway(BaseModel):
    name: str
    description: str
    likelihood: Literal["HIGH", "MODERATE", "LOW", "SPECULATIVE"]
    enabling_conditions: list[str]
    blocking_conditions: list[str]
    timeline_estimate: Optional[str] = None


class EscalationRisk(BaseModel):
    risk_label: str
    description: str
    severity: Literal["CRITICAL", "HIGH", "MODERATE", "LOW"]
    trigger_conditions: list[str]
    mitigating_factors: list[str]


class SynthesisOutput(BaseModel):
    primary_assessment: str
    scenario_pathways: list[ScenarioPathway]
    escalation_risks: list[EscalationRisk]
    adversary_next_move: str = Field(
        description="Mandatory: explicit assessment of what adversarial actors do next"
    )
    residual_uncertainty: list[str]
    confidence_ceiling: Literal["HIGH", "MODERATE", "LOW", "FRAGMENTED"]
    reversal_conditions: list[str] = Field(
        description="What evidence would cause this assessment to reverse"
    )


# ---------------------------------------------------------------------------
# Stage 4 — Executive Brief Agent output
# ---------------------------------------------------------------------------

class ExecutiveBrief(BaseModel):
    """Final output product. Executive-grade. No hype. No unsupported certainty."""
    title: str
    classification_label: str = Field(
        default="OPEN SOURCE INTELLIGENCE — UNCLASSIFIED",
        description="Always OSINT/UNCLASSIFIED for this system"
    )
    executive_summary: str
    signal_map: list[dict[str, Any]] = Field(
        description="Condensed signal registry with weights and categories"
    )
    key_findings: list[str]
    scenario_pathways: list[dict[str, Any]]
    escalation_risk_matrix: list[dict[str, Any]]
    adversary_next_move: str
    confidence_ceiling: Literal["HIGH", "MODERATE", "LOW", "FRAGMENTED"]
    reversal_conditions: list[str]
    recommended_next_move: str = Field(
        description="One concrete analytical or operational action the decision-maker should take next"
    )
    source_notes: str


# ---------------------------------------------------------------------------
# Pipeline State — LangGraph shared state object
# ---------------------------------------------------------------------------

class HSSSEState(BaseModel):
    """Shared state object passed between all LangGraph nodes."""
    run_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    query: str
    raw_sources: list[RawSource] = Field(default_factory=list)
    signal_records: list[SignalRecord] = Field(default_factory=list)
    aicn_output: Optional[AICNOutput] = None
    synthesis_output: Optional[SynthesisOutput] = None
    executive_brief: Optional[ExecutiveBrief] = None
    errors: list[str] = Field(default_factory=list)
