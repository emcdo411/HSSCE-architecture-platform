"""
signal_agent.py
HSSCE MVP — Signal Agent

Accepts the query and raw source documents.
Normalizes each source into a structured SignalRecord.
Does not make strategic judgments. Structures information only.
"""

import json
import re
from typing import Any

import anthropic

from app.config import config
from app.models import HSSSEState, RawSource, SignalRecord
from app.prompts import SIGNAL_AGENT_PROMPT


def _build_user_message(query: str, sources: list[RawSource]) -> str:
    """Construct the user-turn message for the Signal Agent."""
    sources_block = "\n\n".join(
        f"--- SOURCE {i + 1} ---\n"
        f"Title: {s.title}\n"
        f"URL: {s.url or 'Not provided'}\n"
        f"Type: {s.source_type}\n"
        f"Region: {s.region}\n"
        f"Date: {s.publication_date or 'Not provided'}\n"
        f"Content:\n{s.content}"
        for i, s in enumerate(sources)
    )

    return (
        f"ANALYTICAL QUERY:\n{query}\n\n"
        f"SOURCE DOCUMENTS TO NORMALIZE:\n{sources_block}\n\n"
        f"Produce a JSON array of SignalRecord objects for all {len(sources)} sources. "
        f"Return only valid JSON. No preamble. No commentary."
    )


def _parse_signal_records(raw_text: str) -> list[SignalRecord]:
    """Extract and validate SignalRecord objects from the model response."""
    # Strip markdown code fences if present
    cleaned = re.sub(r"```(?:json)?", "", raw_text).strip()
    data = json.loads(cleaned)

    if not isinstance(data, list):
        data = [data]

    records = []
    for item in data:
        try:
            records.append(SignalRecord(**item))
        except Exception as e:
            # Log but continue — partial results are better than failure
            print(f"[SignalAgent] Skipping malformed record: {e}")
    return records


def run_signal_agent(state: HSSSEState) -> HSSSEState:
    """
    LangGraph node: Signal Agent.
    Transforms raw_sources into signal_records.
    """
    if not state.raw_sources:
        state.errors.append("SignalAgent: no sources provided")
        return state

    client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)

    try:
        response = client.messages.create(
            model=config.CLAUDE_MODEL,
            max_tokens=4096,
            system=SIGNAL_AGENT_PROMPT,
            messages=[
                {
                    "role": "user",
                    "content": _build_user_message(state.query, state.raw_sources),
                }
            ],
        )

        raw_text = response.content[0].text
        records = _parse_signal_records(raw_text)
        state.signal_records = records
        print(f"[SignalAgent] Produced {len(records)} signal records.")

    except json.JSONDecodeError as e:
        state.errors.append(f"SignalAgent: JSON parse error — {e}")
    except Exception as e:
        state.errors.append(f"SignalAgent: unexpected error — {e}")

    return state
