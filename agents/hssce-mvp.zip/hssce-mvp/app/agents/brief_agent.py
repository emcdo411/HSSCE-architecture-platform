"""
brief_agent.py
HSSCE MVP — Executive Brief Agent

Converts synthesis output into an executive-grade Action Brief.
No hype. No partisan framing. No unsupported certainty.
Clear enough for a senior decision-maker. Auditable by an analyst.
"""

import json
import re

import anthropic

from app.config import config
from app.models import ExecutiveBrief, HSSSEState, SynthesisOutput, AICNOutput
from app.prompts import BRIEF_AGENT_PROMPT


def _build_user_message(
    query: str,
    synthesis: SynthesisOutput,
    aicn: AICNOutput,
    source_titles: list[str],
) -> str:
    """Construct the user-turn message for the Brief Agent."""
    synthesis_block = json.dumps(synthesis.model_dump(), indent=2)
    aicn_block = json.dumps(aicn.model_dump(), indent=2)
    sources_list = "\n".join(f"  - {t}" for t in source_titles)

    return (
        f"ORIGINAL ANALYTICAL QUERY:\n{query}\n\n"
        f"SOURCE BASE ({len(source_titles)} sources):\n{sources_list}\n\n"
        f"AICN OUTPUT (confidence ceiling and signal weights):\n{aicn_block}\n\n"
        f"STRATEGIC SYNTHESIS OUTPUT:\n{synthesis_block}\n\n"
        f"Produce a complete ExecutiveBrief JSON object. "
        f"Confidence ceiling is {aicn.confidence_ceiling} — do not exceed it. "
        f"Include all mandatory sections. "
        f"Recommended Next Move must be ONE specific action, not a menu. "
        f"Return valid JSON only. No preamble. No commentary."
    )


def _parse_executive_brief(raw_text: str) -> ExecutiveBrief:
    cleaned = re.sub(r"```(?:json)?", "", raw_text).strip()
    data = json.loads(cleaned)
    return ExecutiveBrief(**data)


def run_brief_agent(state: HSSSEState) -> HSSSEState:
    """
    LangGraph node: Executive Brief Agent.
    Transforms SynthesisOutput into a final ExecutiveBrief.
    """
    if not state.synthesis_output or not state.aicn_output:
        state.errors.append("BriefAgent: synthesis or AICN output missing")
        return state

    client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)
    source_titles = [s.source_title for s in state.signal_records]

    try:
        response = client.messages.create(
            model=config.CLAUDE_MODEL,
            max_tokens=6000,
            system=BRIEF_AGENT_PROMPT,
            messages=[
                {
                    "role": "user",
                    "content": _build_user_message(
                        state.query,
                        state.synthesis_output,
                        state.aicn_output,
                        source_titles,
                    ),
                }
            ],
        )

        raw_text = response.content[0].text
        brief = _parse_executive_brief(raw_text)
        state.executive_brief = brief

        print(f"[BriefAgent] Executive brief produced. Ceiling: {brief.confidence_ceiling}.")

    except json.JSONDecodeError as e:
        state.errors.append(f"BriefAgent: JSON parse error — {e}")
    except Exception as e:
        state.errors.append(f"BriefAgent: unexpected error — {e}")

    return state
