"""
aicn_agent.py
HSSCE MVP — AICN Calibration Agent

Scores each signal using the AICN weighting formula.
Detects conflicts. Produces a confidence ceiling.
This is the anti-hallucination backbone of the pipeline.
"""

import json
import re

import anthropic

from app.config import config
from app.models import AICNOutput, HSSSEState, SignalRecord
from app.prompts import AICN_AGENT_PROMPT


def _build_user_message(query: str, signal_records: list[SignalRecord]) -> str:
    """Construct the user-turn message for the AICN Agent."""
    signals_block = json.dumps(
        [r.model_dump() for r in signal_records], indent=2
    )

    return (
        f"ANALYTICAL QUERY:\n{query}\n\n"
        f"SIGNAL RECORDS TO CALIBRATE:\n{signals_block}\n\n"
        f"Apply AICN scoring to all {len(signal_records)} signal records. "
        f"Detect all conflicts. Determine the confidence ceiling. "
        f"List all residual uncertainties. "
        f"Return a complete AICNOutput JSON object. No preamble. No commentary. Valid JSON only."
    )


def _parse_aicn_output(raw_text: str) -> AICNOutput:
    """Extract and validate AICNOutput from the model response."""
    cleaned = re.sub(r"```(?:json)?", "", raw_text).strip()
    data = json.loads(cleaned)
    return AICNOutput(**data)


def run_aicn_agent(state: HSSSEState) -> HSSSEState:
    """
    LangGraph node: AICN Calibration Agent.
    Transforms signal_records into a calibrated AICNOutput.
    """
    if not state.signal_records:
        state.errors.append("AICNAgent: no signal records to calibrate")
        return state

    client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)

    try:
        response = client.messages.create(
            model=config.CLAUDE_MODEL,
            max_tokens=4096,
            system=AICN_AGENT_PROMPT,
            messages=[
                {
                    "role": "user",
                    "content": _build_user_message(state.query, state.signal_records),
                }
            ],
        )

        raw_text = response.content[0].text
        aicn_output = _parse_aicn_output(raw_text)
        state.aicn_output = aicn_output

        print(
            f"[AICNAgent] Calibrated {len(aicn_output.weighted_signals)} signals. "
            f"Ceiling: {aicn_output.confidence_ceiling}. "
            f"Conflicts: {len(aicn_output.conflicts)}."
        )

    except json.JSONDecodeError as e:
        state.errors.append(f"AICNAgent: JSON parse error — {e}")
    except Exception as e:
        state.errors.append(f"AICNAgent: unexpected error — {e}")

    return state
