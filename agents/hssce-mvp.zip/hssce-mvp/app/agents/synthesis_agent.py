"""
synthesis_agent.py
HSSCE MVP — Strategic Synthesis Agent

Uses calibrated AICN output to produce:
- Scenario pathways
- Escalation risk modeling
- Adversary next-move assessment (mandatory)
- Reversal conditions

Operates under WCIS v5.2 analytical standards.
"""

import json
import re

import anthropic

from app.config import config
from app.models import AICNOutput, HSSSEState, SynthesisOutput
from app.prompts import SYNTHESIS_AGENT_PROMPT


def _build_user_message(
    query: str, aicn_output: AICNOutput, signal_summary: str
) -> str:
    """Construct the user-turn message for the Synthesis Agent."""
    aicn_block = json.dumps(aicn_output.model_dump(), indent=2)

    return (
        f"ANALYTICAL QUERY:\n{query}\n\n"
        f"SIGNAL CONTEXT SUMMARY:\n{signal_summary}\n\n"
        f"AICN CALIBRATION OUTPUT:\n{aicn_block}\n\n"
        f"Produce a complete SynthesisOutput JSON object. "
        f"Your confidence ceiling is locked to: {aicn_output.confidence_ceiling}. "
        f"Adversary Next Move section is mandatory. "
        f"Every scenario pathway requires reversal conditions. "
        f"Return valid JSON only. No preamble. No commentary."
    )


def _build_signal_summary(state: HSSSEState) -> str:
    """Build a condensed plain-text summary of signal records for the synthesis prompt."""
    lines = []
    for rec in state.signal_records:
        lines.append(
            f"[{rec.id}] {rec.source_title} ({rec.source_type}, {rec.region}): "
            f"{rec.summary}"
        )
    return "\n".join(lines)


def _parse_synthesis_output(raw_text: str) -> SynthesisOutput:
    cleaned = re.sub(r"```(?:json)?", "", raw_text).strip()
    data = json.loads(cleaned)
    return SynthesisOutput(**data)


def run_synthesis_agent(state: HSSSEState) -> HSSSEState:
    """
    LangGraph node: Strategic Synthesis Agent.
    Transforms AICNOutput into SynthesisOutput.
    """
    if not state.aicn_output:
        state.errors.append("SynthesisAgent: no AICN output available")
        return state

    client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)
    signal_summary = _build_signal_summary(state)

    try:
        response = client.messages.create(
            model=config.CLAUDE_MODEL,
            max_tokens=6000,
            system=SYNTHESIS_AGENT_PROMPT,
            messages=[
                {
                    "role": "user",
                    "content": _build_user_message(
                        state.query, state.aicn_output, signal_summary
                    ),
                }
            ],
        )

        raw_text = response.content[0].text
        synthesis_output = _parse_synthesis_output(raw_text)
        state.synthesis_output = synthesis_output

        print(
            f"[SynthesisAgent] Produced {len(synthesis_output.scenario_pathways)} pathways, "
            f"{len(synthesis_output.escalation_risks)} escalation risks."
        )

    except json.JSONDecodeError as e:
        state.errors.append(f"SynthesisAgent: JSON parse error — {e}")
    except Exception as e:
        state.errors.append(f"SynthesisAgent: unexpected error — {e}")

    return state
