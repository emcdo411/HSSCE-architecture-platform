"""
graph.py
HSSCE MVP — LangGraph workflow orchestration.

Defines the four-node pipeline:
  START -> signal_agent -> aicn_agent -> synthesis_agent -> brief_agent -> END

Each node receives the full HSSSEState, updates only its designated fields,
and returns the updated state. Errors are collected in state.errors rather
than raising exceptions, so the pipeline completes even with partial failures.
"""

from langgraph.graph import StateGraph, END
from app.models import HSSSEState
from app.agents.signal_agent import run_signal_agent
from app.agents.aicn_agent import run_aicn_agent
from app.agents.synthesis_agent import run_synthesis_agent
from app.agents.brief_agent import run_brief_agent


def _signal_node(state: dict) -> dict:
    s = HSSSEState(**state)
    result = run_signal_agent(s)
    return result.model_dump()


def _aicn_node(state: dict) -> dict:
    s = HSSSEState(**state)
    result = run_aicn_agent(s)
    return result.model_dump()


def _synthesis_node(state: dict) -> dict:
    s = HSSSEState(**state)
    result = run_synthesis_agent(s)
    return result.model_dump()


def _brief_node(state: dict) -> dict:
    s = HSSSEState(**state)
    result = run_brief_agent(s)
    return result.model_dump()


def build_graph() -> StateGraph:
    """Construct and compile the HSSCE LangGraph workflow."""
    workflow = StateGraph(dict)

    workflow.add_node("signal_agent", _signal_node)
    workflow.add_node("aicn_agent", _aicn_node)
    workflow.add_node("synthesis_agent", _synthesis_node)
    workflow.add_node("brief_agent", _brief_node)

    workflow.set_entry_point("signal_agent")
    workflow.add_edge("signal_agent", "aicn_agent")
    workflow.add_edge("aicn_agent", "synthesis_agent")
    workflow.add_edge("synthesis_agent", "brief_agent")
    workflow.add_edge("brief_agent", END)

    return workflow.compile()


# Module-level compiled graph instance
hssce_graph = build_graph()


def run_pipeline(query: str, raw_sources: list) -> HSSSEState:
    """
    Execute the full HSSCE pipeline for a given query and source list.
    Returns the final HSSSEState.
    """
    from app.models import RawSource

    # Normalize raw_sources to RawSource objects if dicts were passed
    normalized = []
    for s in raw_sources:
        if isinstance(s, dict):
            normalized.append(RawSource(**s))
        else:
            normalized.append(s)

    initial_state = HSSSEState(query=query, raw_sources=normalized)
    result_dict = hssce_graph.invoke(initial_state.model_dump())
    return HSSSEState(**result_dict)
