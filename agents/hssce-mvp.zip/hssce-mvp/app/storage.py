"""
storage.py
HSSCE MVP — JSON file-based audit logging for analysis runs.

Stores every completed run with its full state for retrieval and audit.
Uses a simple JSON file as the backing store for MVP simplicity.
"""

import json
import os
from datetime import datetime, timezone
from typing import Any, Optional
from app.models import HSSSEState


RUNS_PATH = os.path.join(os.path.dirname(__file__), "data", "runs.json")


def _load_runs() -> dict[str, Any]:
    """Load all runs from the JSON store."""
    if not os.path.exists(RUNS_PATH):
        return {}
    with open(RUNS_PATH, "r") as f:
        try:
            data = json.load(f)
            # Handle legacy list format from empty initialization
            if isinstance(data, list):
                return {}
            return data
        except json.JSONDecodeError:
            return {}


def _save_runs(runs: dict[str, Any]) -> None:
    """Persist the runs dict to disk."""
    os.makedirs(os.path.dirname(RUNS_PATH), exist_ok=True)
    with open(RUNS_PATH, "w") as f:
        json.dump(runs, f, indent=2)


def save_run(state: HSSSEState) -> None:
    """Save a completed run state to the audit log."""
    runs = _load_runs()
    runs[state.run_id] = {
        "run_id": state.run_id,
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "query": state.query,
        "signal_count": len(state.signal_records),
        "confidence_ceiling": (
            state.aicn_output.confidence_ceiling if state.aicn_output else None
        ),
        "errors": state.errors,
        "executive_brief": (
            state.executive_brief.model_dump() if state.executive_brief else None
        ),
        "full_state": state.model_dump(),
    }
    _save_runs(runs)


def get_run(run_id: str) -> Optional[dict[str, Any]]:
    """Retrieve a single run by ID."""
    runs = _load_runs()
    return runs.get(run_id)


def list_runs() -> list[dict[str, Any]]:
    """Return summary records for all stored runs."""
    runs = _load_runs()
    summaries = []
    for run_id, run_data in runs.items():
        summaries.append({
            "run_id": run_id,
            "completed_at": run_data.get("completed_at"),
            "query": run_data.get("query"),
            "signal_count": run_data.get("signal_count"),
            "confidence_ceiling": run_data.get("confidence_ceiling"),
            "errors": run_data.get("errors", []),
        })
    # Most recent first
    summaries.sort(key=lambda x: x.get("completed_at", ""), reverse=True)
    return summaries
