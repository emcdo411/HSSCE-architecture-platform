"""
config.py
HSSCE MVP — Configuration and environment management.
"""

import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    ANTHROPIC_API_KEY: str = os.getenv("ANTHROPIC_API_KEY", "")
    CLAUDE_MODEL: str = os.getenv("CLAUDE_MODEL", "claude-sonnet-4-20250514")
    DATABASE_PATH: str = os.getenv("DATABASE_PATH", "app/data/runs.json")
    USE_SAMPLE_DATA: bool = os.getenv("USE_SAMPLE_DATA", "false").lower() == "true"

    @classmethod
    def validate(cls) -> None:
        if not cls.ANTHROPIC_API_KEY:
            raise EnvironmentError(
                "ANTHROPIC_API_KEY is not set. "
                "Copy .env.example to .env and add your key."
            )


config = Config()
