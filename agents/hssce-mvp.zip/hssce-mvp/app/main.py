"""
main.py
HSSCE MVP — FastAPI application layer.

Endpoints:
  GET  /              System status
  GET  /health        Health check
  POST /analyze       Run full pipeline against provided query and sources
  GET  /runs          List all prior analysis runs
  GET  /runs/{run_id} Retrieve a single prior run
  POST /sample/cuba   Run the Cuba stabilization flagship query against sample data
"""

import json
import os
from datetime import datetime, timezone
from typing import Any, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from app.config import config
from app.graph import run_pipeline
from app.models import ExecutiveBrief, HSSSEState, RawSource
from app.storage import get_run, list_runs, save_run


# ---------------------------------------------------------------------------
# App initialization
# ---------------------------------------------------------------------------

app = FastAPI(
    title="HSSCE MVP",
    description=(
        "Hemispheric Stabilization & Strategic Calibration Engine — "
        "Civilian-safe open-source strategic intelligence calibration platform. "
        "WCIS v5.2 | AICN Signal Calibration | North Star Intelligence."
    ),
    version="0.1.0",
)

# CORS: allow the existing HTML frontend to call this API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Request/response schemas
# ---------------------------------------------------------------------------

class AnalysisRequest(BaseModel):
    query: str
    sources: Optional[list[RawSource]] = None


class AnalysisResponse(BaseModel):
    run_id: str
    query: str
    executive_brief: Optional[ExecutiveBrief]
    errors: list[str]
    confidence_ceiling: Optional[str]
    signal_count: int


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/")
def root() -> dict[str, Any]:
    return {
        "system": "HSSCE — Hemispheric Stabilization & Strategic Calibration Engine",
        "version": "0.1.0-mvp",
        "status": "operational",
        "classification": "OPEN SOURCE INTELLIGENCE — UNCLASSIFIED",
        "framework": "WCIS v5.2 | AICN | North Star Intelligence",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "endpoints": {
            "analyze": "POST /analyze",
            "sample_cuba": "POST /sample/cuba",
            "runs": "GET /runs",
            "run_detail": "GET /runs/{run_id}",
            "health": "GET /health",
        },
    }


@app.get("/health")
def health() -> dict[str, str]:
    api_key_set = bool(config.ANTHROPIC_API_KEY)
    return {
        "status": "healthy" if api_key_set else "degraded",
        "anthropic_api_key": "set" if api_key_set else "missing",
        "model": config.CLAUDE_MODEL,
    }


@app.post("/analyze", response_model=AnalysisResponse)
def analyze(request: AnalysisRequest) -> AnalysisResponse:
    """
    Run the full four-agent HSSCE pipeline.

    Provide a query and optionally a list of source documents.
    If no sources are provided, the pipeline will use the sample Cuba sources.
    """
    try:
        config.validate()
    except EnvironmentError as e:
        raise HTTPException(status_code=503, detail=str(e))

    sources = request.sources or _load_sample_sources()

    if not sources:
        raise HTTPException(
            status_code=400,
            detail="No sources provided and sample_sources.json could not be loaded.",
        )

    state: HSSSEState = run_pipeline(query=request.query, raw_sources=sources)
    save_run(state)

    return AnalysisResponse(
        run_id=state.run_id,
        query=state.query,
        executive_brief=state.executive_brief,
        errors=state.errors,
        confidence_ceiling=(
            state.aicn_output.confidence_ceiling if state.aicn_output else None
        ),
        signal_count=len(state.signal_records),
    )


@app.get("/runs")
def get_runs() -> list[dict[str, Any]]:
    """Return summary records for all prior analysis runs."""
    return list_runs()


@app.get("/runs/{run_id}")
def get_single_run(run_id: str) -> dict[str, Any]:
    """Return full state for a single prior run."""
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run {run_id} not found.")
    return run


@app.post("/sample/cuba", response_model=AnalysisResponse)
def run_cuba_sample() -> AnalysisResponse:
    """
    Execute the HSSCE flagship query against the bundled Cuba sample sources.

    Query: Under what realistic geopolitical, economic, and strategic conditions
    could Cuba transition from adversarial liability to hemispheric stabilization
    opportunity for the United States while reducing escalation risk and improving
    regional resilience?
    """
    try:
        config.validate()
    except EnvironmentError as e:
        raise HTTPException(status_code=503, detail=str(e))

    sources = _load_sample_sources()
    if not sources:
        raise HTTPException(
            status_code=500,
            detail="sample_sources.json could not be loaded.",
        )

    query = (
        "Under what realistic geopolitical, economic, and strategic conditions "
        "could Cuba transition from adversarial liability to hemispheric stabilization "
        "opportunity for the United States while reducing escalation risk and improving "
        "regional resilience?"
    )

    state: HSSSEState = run_pipeline(query=query, raw_sources=sources)
    save_run(state)

    return AnalysisResponse(
        run_id=state.run_id,
        query=state.query,
        executive_brief=state.executive_brief,
        errors=state.errors,
        confidence_ceiling=(
            state.aicn_output.confidence_ceiling if state.aicn_output else None
        ),
        signal_count=len(state.signal_records),
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_sample_sources() -> list[RawSource]:
    """Load sample sources from the bundled JSON file."""
    sample_path = os.path.join(
        os.path.dirname(__file__), "data", "sample_sources.json"
    )
    if not os.path.exists(sample_path):
        return []
    with open(sample_path, "r") as f:
        raw = json.load(f)
    return [RawSource(**item) for item in raw]
