"""
run_local.py
HSSCE MVP — Local development runner.

Usage:
  python run_local.py

Starts the FastAPI server on http://localhost:8000.
Requires .env file with ANTHROPIC_API_KEY set.
"""

import uvicorn

if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info",
    )
