# HSSCE MVP

## Hemispheric Stabilization & Strategic Calibration Engine

**Classification:** OPEN SOURCE INTELLIGENCE — UNCLASSIFIED
**Framework:** WCIS v5.2 | AICN Signal Calibration | North Star Intelligence
**Architecture:** Erwin Maurice McDonald — Epoch Frameworks LLC

---

## What This Is

HSSCE MVP is a working backend orchestration layer for a civilian-safe, open-source strategic intelligence calibration platform.

It implements a four-agent LangGraph pipeline that ingests source documents, calibrates their signal weight using the AICN scoring model, synthesizes scenario pathways and escalation risks using WCIS v5.2 analytical standards, and produces executive-grade Action Briefs.

The flagship analytical question driving the architecture:

> Under what realistic geopolitical, economic, and strategic conditions could Cuba transition from adversarial liability to hemispheric stabilization opportunity for the United States while reducing escalation risk and improving regional resilience?

---

## What This Is Not

This system is not:

- A prediction engine. It calibrates confidence distributions, not certainties.
- A partisan platform. It applies incentive bias correction symmetrically to all sources.
- A classified intelligence system. It operates entirely within open-source, unclassified information domains.
- An autonomous decision-making system. It produces analysis for human decision-makers.
- A replacement for institutional intelligence. It is a structured calibration framework for public information environments.

---

## Architecture

### Four-Agent LangGraph Pipeline

```
START
  |
  v
[1] Signal Agent
    - Accepts query and source documents
    - Normalizes each source into a structured SignalRecord
    - Flags incentive bias
    - Does not make strategic judgments
  |
  v
[2] AICN Calibration Agent
    - Scores each signal using the AICN weighting formula
    - Detects factual, interpretive, and structural conflicts
    - Produces a weighted confidence distribution
    - Determines the confidence ceiling for the entire analysis
    - Lists residual uncertainties
  |
  v
[3] Strategic Synthesis Agent
    - Uses calibrated signals to build scenario pathways
    - Models adversary next moves (mandatory output)
    - Identifies escalation risks
    - Assigns confidence ceilings per scenario
    - States reversal conditions for every pathway
  |
  v
[4] Executive Brief Agent
    - Converts synthesis into an executive-grade Action Brief
    - Applies WCIS Walker Decision Superiority standard
    - No hype, no unsupported certainty, no partisan framing
    - Produces one specific recommended next analytical move
  |
  v
END
```

---

## AICN Scoring Model

The Adversarial Intelligence Calibration Node applies this formula to every signal:

```
Raw Score = (Domain Proximity + Track Record) / 2

Adjusted Weight = Raw Score x Incentive Bias Correction x Timeliness Decay
```

**Scoring ranges:**

| Factor | Range | Description |
|--------|-------|-------------|
| Domain Proximity | 1.0 to 5.0 | How close the source's domain expertise is to the subject |
| Track Record | 1.0 to 5.0 | Reliability and accuracy history of this source type |
| Incentive Bias Correction | 0.50 to 1.00 | Reduces weight for sources with strong institutional interest in a particular outcome |
| Timeliness Decay | 0.50 to 1.00 | Reduces weight for older or rapidly superseded information |

**Category thresholds:**

| Adjusted Weight | Category |
|-----------------|----------|
| 4.0 to 5.0 | HIGH |
| 2.5 to 3.9 | MODERATE |
| 1.0 to 2.4 | LOW |
| Below 1.0 | DEGRADED |

**Confidence ceiling rules:**

| Ceiling | Condition |
|---------|-----------|
| HIGH | Multiple independent HIGH or MODERATE signals converge on the same conclusion; no CRITICAL conflict |
| MODERATE | Convergence present but unresolved contradictions remain |
| LOW | Limited corroboration or heavy interpretive dependency |
| FRAGMENTED | Signals too sparse, contradictory, or from too few independent sources |

**The governing principle:** Intelligence confidence is not a function of how many sources agree. It is a function of how much independent, high-quality, unbiased, timely signal weight supports a position — and how clearly the system identifies what it does not know.

---

## Project Structure

```
hssce-mvp/
|-- app/
|   |-- __init__.py
|   |-- main.py          FastAPI application and endpoints
|   |-- graph.py         LangGraph workflow orchestration
|   |-- config.py        Environment and configuration management
|   |-- models.py        Pydantic data models for all pipeline stages
|   |-- prompts.py       Disciplined system prompts for each agent
|   |-- storage.py       JSON-based audit logging
|   |-- agents/
|   |   |-- __init__.py
|   |   |-- signal_agent.py     Stage 1: Signal normalization
|   |   |-- aicn_agent.py       Stage 2: AICN calibration
|   |   |-- synthesis_agent.py  Stage 3: Strategic synthesis
|   |   |-- brief_agent.py      Stage 4: Executive brief generation
|   |-- data/
|       |-- sample_sources.json  8 mock Cuba strategic intelligence sources
|       |-- runs.json            Audit log (auto-created)
|-- tests/
|   |-- __init__.py
|   |-- test_graph.py    Structural and unit tests (no API calls required)
|-- .env.example         Environment configuration template
|-- requirements.txt     Python dependencies
|-- README.md            This file
|-- run_local.py         Local development server launcher
```

---

## Installation

**Requirements:** Python 3.11 or higher.

```bash
# Clone or download the project
cd hssce-mvp

# Create and activate a virtual environment
python -m venv .venv
source .venv/bin/activate        # macOS / Linux
.venv\Scripts\activate           # Windows

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env and set ANTHROPIC_API_KEY=your_key_here
```

---

## Running Locally

```bash
python run_local.py
```

The API will be available at `http://localhost:8000`.

Interactive documentation is at `http://localhost:8000/docs`.

---

## Running the Tests

The test suite validates model schemas, the AICN formula, state transitions, and storage. It does not make live API calls.

```bash
pytest tests/ -v
```

---

## API Reference

### GET /

Returns system status and endpoint map.

### GET /health

Returns health check including API key configuration status.

### POST /analyze

Run the full four-agent pipeline.

**Request body:**

```json
{
  "query": "Your analytical question here",
  "sources": [
    {
      "title": "Source Title",
      "url": "https://optional-url.com",
      "source_type": "policy_document",
      "region": "US",
      "content": "Full text or summary of the source document.",
      "publication_date": "2024-01-15"
    }
  ]
}
```

If `sources` is omitted, the system will use the bundled Cuba sample sources.

**Valid source_type values:** state_media, think_tank, journalism, policy_document, market_data, academic, ngo_report, commercial_intelligence

**Valid region values:** Any string — US, Cuba, Latin_America, China, Russia, EU, etc.

### GET /runs

Returns summary records for all prior analysis runs.

### GET /runs/{run_id}

Returns the full state for a specific prior run, including all intermediate outputs.

### POST /sample/cuba

Runs the HSSCE flagship Cuba query against the bundled sample sources. No request body required.

---

## Example curl Commands

**Health check:**

```bash
curl http://localhost:8000/health
```

**Run Cuba sample analysis:**

```bash
curl -X POST http://localhost:8000/sample/cuba
```

**Run custom analysis:**

```bash
curl -X POST http://localhost:8000/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "query": "What are the primary escalation risk vectors in the Taiwan Strait over the next 18 months?",
    "sources": [
      {
        "title": "Example Think Tank Brief",
        "source_type": "think_tank",
        "region": "US",
        "content": "China has conducted 14 military exercises near Taiwan in the past 12 months...",
        "publication_date": "2024-10-01"
      }
    ]
  }'
```

**Retrieve prior runs:**

```bash
curl http://localhost:8000/runs
curl http://localhost:8000/runs/{run_id}
```

---

## Connecting the Existing HTML Frontend

The existing HTML/GitHub Pages frontend can connect to this API by making fetch calls to the FastAPI endpoints.

**Example integration in your frontend JavaScript:**

```javascript
// Run the Cuba sample analysis
async function runCubaAnalysis() {
  const response = await fetch('http://localhost:8000/sample/cuba', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  });
  const data = await response.json();
  renderExecutiveBrief(data.executive_brief);
}

// Run a custom analysis
async function runAnalysis(query, sources) {
  const response = await fetch('http://localhost:8000/analyze', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, sources })
  });
  const data = await response.json();
  return data;
}
```

For production deployment, replace `http://localhost:8000` with your deployed API URL and restrict CORS origins in `main.py` accordingly.

For GitHub Pages hosting, the frontend will need to call an externally accessible API. Options include: Railway, Render, or Fly.io for FastAPI deployment.

---

## Output Structure

The `executive_brief` field in every response follows this structure:

```json
{
  "title": "Analysis title",
  "classification_label": "OPEN SOURCE INTELLIGENCE — UNCLASSIFIED",
  "executive_summary": "3-4 paragraph summary",
  "signal_map": [ ... ],
  "key_findings": [ "Finding 1", "Finding 2" ],
  "scenario_pathways": [ ... ],
  "escalation_risk_matrix": [ ... ],
  "adversary_next_move": "Explicit adversary next move assessment",
  "confidence_ceiling": "MODERATE",
  "reversal_conditions": [ "Condition 1", "Condition 2" ],
  "recommended_next_move": "One specific analytical action",
  "source_notes": "Brief statement on source base limitations"
}
```

---

## Limitations

1. **Source quality is the ceiling.** The pipeline calibrates and synthesizes whatever sources are provided. Poor source selection produces poor analysis regardless of pipeline sophistication.

2. **The confidence ceiling is a floor constraint, not a guarantee.** AICN prevents confidence inflation but cannot produce certainty from inherently uncertain source material.

3. **No persistent memory between runs.** Each pipeline invocation starts fresh. The runs.json audit log preserves outputs but the agents do not use prior runs as context.

4. **No live signal ingestion in MVP.** Sources must be provided by the caller. Live ingestion (n8n, MCP, web search) is a Phase 2 capability.

5. **JSON parsing brittleness.** Agent outputs are parsed from structured JSON returned by the language model. Occasional parsing failures are handled gracefully via error logging, but complex queries may require retry logic.

---

## Safety Boundaries

All agent prompts enforce the following non-negotiable constraints:

- No classified claims or implications
- No advocacy for military intervention or regime change
- No partisan framing
- No fabricated citations or invented sources
- No confidence inflation beyond what signal weight supports
- Explicit uncertainty in all outputs
- Mandatory reversal conditions for all analytical positions

These constraints are embedded in the system prompts and cannot be removed by user input.

---

## Next Development Phases

**Phase 2: Live Signal Ingestion**
- Integrate web search tooling (Tavily or Brave Search API)
- Build n8n pipelines for scheduled source ingestion
- Add MCP tooling for structured data sources

**Phase 3: Full Domain Agent Architecture**
- Expand to 12 parallel domain specialist agents per the HSSCE architecture document
- Implement parallel execution in LangGraph
- Add domain isolation protocols

**Phase 4: Persistent Vector Memory**
- Integrate Pinecone or ChromaDB for RAG-based signal retrieval
- Enable cross-run signal continuity

**Phase 5: Executive Dashboard**
- Connect Next.js frontend with Plotly confidence visualizations
- Build real-time run monitoring
- Add scenario comparison tooling

---

## Author

Erwin Maurice McDonald
Epoch Frameworks LLC — Behavioral Intelligence Research
WCIS v5.2 | AICN | HSSCE | North Star Intelligence
DACR License v2.7
